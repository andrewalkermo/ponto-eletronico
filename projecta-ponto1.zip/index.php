<?php
    include (__DIR__ . '/views/ponto/index.php');
//    header('Location: ./views/ponto/');
    exit();
?>
