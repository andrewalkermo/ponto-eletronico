<?php
    header('Location: ./views/ponto/');
    exit();
?>
